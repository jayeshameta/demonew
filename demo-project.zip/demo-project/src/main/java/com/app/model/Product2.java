package com.app.model;

import lombok.Data;

@Data
public class Product2 {
    private String productId;
    private String productName;
    private String unitOfMeasure;
    private String launchDate;
}
